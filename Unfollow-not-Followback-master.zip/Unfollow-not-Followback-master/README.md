# Instagram Bot Tools

# install

* git clone https://github.com/ccocot/Unfollow-not-Followback.git
* cd Unfollow-not-Followback
* npm install

Thank's To https://github.com/huttarichard/instagram-private-api For API
